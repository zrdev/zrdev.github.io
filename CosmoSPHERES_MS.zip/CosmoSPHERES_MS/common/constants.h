//
//  constants.h
//
//
//  Created by Ethan DiNinno on 4/11/13.
//
//

#ifndef _constants_h
#define _constants_h

//#undef ZR2D
#undef ZR3D
#define ALLIANCE

#define ME 0
#define OTHER 1
#define	EMPTY_TIME 95

const float iz_bounds[3] = {0.64f,0.80f,0.64f};
const float item0[3] = {0.5f, 0.65f, 0.0f};

//Sphere Properties
#define SPHERE_MASS 1e-5f
#define SPHERE_MAX_VEL 0.05f

//Net property
#define LENGTH_NET 0.45f

//Comet properties
#define COMET_MASS 1 
#define COMET_RADIUS 0.07f
#define G 1
#define COMET_TIME 91

//Debris Configurations
#ifdef ZR2D 
	const float	DEBRIS_LOCS[8][4][3] = {
		{{0.523f, -0.5f, 0.0f}, {0.18f, -0.20f, 0.0f}, {0.43f, 0.15f, 0.0f}, {0.15f, 0.37f, 0.0f}},
		{{0.31f, -0.46f, 0.0f}, {0.46f, -0.125f, 0.0f}, {0.13f, -0.11f, 0.0f}, {0.315f, 0.19f, 0.0f}},
		{{0.29f, -0.48f, 0.0f}, {0.53f, -0.135f, 0.0f}, {0.2f, 0.0f, 0.0f}, {0.43f, 0.18f, 0.0f}},
		{{0.28f, -0.46f, 0.0f}, {0.514f, -0.28f, 0.0f}, {0.19f, -0.12f, 0.0f}, {0.48f, 0.18f, 0.0f}},
		{{0.24f, -0.46f, 0.0f}, {0.55f, -0.26f, 0.0f}, {0.16f, -0.06f, 0.0f}, {0.4f, 0.165f, 0.0f}},
		{{0.512f, -0.45f, 0.0f}, {0.03f, -0.21f, 0.0f}, {0.4f, 0.0f, 0.0f}, {0.11f, 0.12f, 0.0f}},
		{{0.15f, -0.45f, 0.0f}, {0.62f, -0.28f, 0.0f}, {0.14f, 0.14f, 0.0f}, {0.576f, 0.3f, 0.0f}},
		{{0.5f, -0.47f, 0.0f}, {0.22f, -0.23f, 0.0f}, {0.6f, -0.132f, 0.0f}, {0.234f, 0.14f, 0.0f}}
	};
#else
	const float DEBRIS_LOCS[5][8][3] = {
		{{0.3f, -0.3f, 0.1f}, {0.1f, -0.3f, -0.4f}, {0.35f, -0.2f, -0.2f}, {0.1f, -0.15f, 0.3f}, 
		{0.45f, 0.15f, -0.1f}, {0.3f, 0.15f, 0.25f}, {0.05f, 0.3f, 0.45f}, {0.2f, 0.35f, -0.15f}},
		{{0.35f, -0.35f, 0.05f}, {0.1f, -0.35f, -0.4f}, {0.5f, -0.25f, 0.25f}, {0.35f, 0.0f, -0.25f},
		{0.15f, 0.05f, 0.1f}, {0.3f, 0.15f, 0.45f}, {0.1f, 0.3f, -0.45f}, {0.45f, 0.4f, 0.1f}},
		{{0.1f, -0.4f, 0.4f}, {0.25f, -0.25f, 0.15f}, {0.2f, -0.25f, -0.35f}, {0.45f, -0.05f, 0.0f},
		{0.45f, 0.1f, -0.35f}, {0.1f, 0.2f, -0.25f}, {0.25f, 0.25f, 0.35f}, {0.2f, 0.4f, 0.0f}},
		{{0.45f, -0.35f, 0.1f}, {0.25f, -0.3f, -0.4f}, {0.1f, -0.2f, -0.15f}, {0.3f, -0.1f, 0.4f},
		{0.45f, 0.0f, 0.0f}, {0.05f, 0.2f, 0.15f}, {0.4f, 0.3f, -0.25f}, {0.2f, 0.35f, 0.45f}},
		{{0.25f, -0.4f, 0.1f}, {0.35f, -0.35f, -0.3f}, {0.05f, -0.2f, 0.4f}, {0.45f, -0.1f, 0.0f},
		{0.1f, 0.05f, -0.15f}, {0.3f, 0.2f, 0.1f}, {0.15f, 0.35f, -0.35f}, {0.4f, 0.45f, 0.3f}}
	};
#endif

//Debris properties
#ifdef ZR2D
	#define NUM_DEBRIS 8
#else
	#define NUM_DEBRIS 16
#endif
#ifdef ALLIANCE
	#define DEBRIS_RADIUS 0.04f
#else
	#define DEBRIS_RADIUS 0.03f
#endif
#define DEBRIS_MASS 3e-6f * 10/NUM_DEBRIS
#define COLLIDE 1
#define NET 2
#define LASSO 3

//Lasso Properties
#define ANGLE PI/6.0f
#define LASSO_BREAK 0.25f 

//Pellets
#define PELLET_IMPULSE 0.00123f 
#define NUM_PELLETS 10

//Item Pickup Constants
#define     NUM_ITEMS 2
#define		ITEM_EMPTY 0x0fff
#define		ITEM_RADIUS 0.05f		//!<(cm) Radius within which an item can be picked up
#define		ITEM_SPEED  0.01f			//!<(1 cm/s) Speed must be below this to pick up an item
#define		ITEM_ROTATION_ANGLE 0.707106 //!<(rad) Rotation of satellite needed to pick up item (cos(90/2))
#define		MAX_START_ITEM  0.04f	//Max AngularVelocity allowed when starting to pick up an item or creat an obstacle

//Fuel Management Variables
#define		MIN_FUEL(a, b) ((a < b) ? b : a) //Prevents fuel from being less than 0
#define		MAX_FUEL(c, d) ((c < d) ? c : d) //Prevents fuel from being greater than PROP_ALLOWED_SECONDS
#define		PROP_ALLOWED_SECONDS 50.0f //Total time in thruster-seconds allowed per user. Full tank ~50 seconds.

//Penalty Variables
#define		OFFSIDES_PENALTY    0.04f
#define		OOBgain             10 //used to slow down satellite
#define		DRAG                1000.0f  //DRAG coefficient while in obstacle
#define		HIT_SECONDS			3

//Scoring constants
#define SCORE_SCALE 20.0f

//Dimensions of Zones
#define ZONE1_WIDTH 0.25f
#define ZONE2_WIDTH 1.1f
#define ZONE3_WIDTH 0.25f

//Interaction zone limits
#define ZONE_pX		0.64f	
#define ZONE_pY		0.8f
#define ZONE_pZ		0.225f
#define ZONE_nX		-ZONE_pX
#define ZONE_nY		-ZONE_pY
#define ZONE_nZ		-ZONE_pZ
const float limits[3] = {ZONE_pX,ZONE_pY,ZONE_pZ};

#endif
