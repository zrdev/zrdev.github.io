#ifndef _ZR_GAME_INTERNAL_H_
#define _ZR_GAME_INTERNAL_H_

#include "constants.h"
#include "ZeroRoboticsGameBaseImpl.hpp"
#include "comm.h"

///Forward declaration of ZR Game
class ZeroRoboticsGame;

/**
 * This class defines the hidden game implementation. Any internal
 * utility functions or game rules functsions hould be put here.  You may also
 * override any of the standard GSP functions by implementing
 * them here.  The functions init(), update(), and sendDebug() are required.
 */
class ZeroRoboticsGameImpl : public ZeroRoboticsGameBaseImpl<ZeroRoboticsGameImpl>
{

public:

    struct PlayerInfo {
        unsigned short debrisTime[NUM_DEBRIS];
        unsigned short pickupCode[NUM_DEBRIS];	///How it was picked up (COLLIDE, LASSO, NET)
		unsigned short itemTime[NUM_ITEMS];
		unsigned short numCollision;
		bool acquiringItem[NUM_ITEMS];			///True if item is in the process of being picked up
		float initQuat[4];						///Initial quaternion when picking up item
		unsigned int pellets;
		float cometState[6];
        float userForces[6];
        bool collisionActive;					/// Variables for Collision
		int recoilTime;
		float recoilRate[3];
		bool hitActive;							/// Flag for bounce, collision with comet
		bool slowActive;						/// Flag for slow down, collision with debris
		float hitPos[3];
		float hitVel[3];
		unsigned int hitTime;					///True if they have passed the midway area
		float fuelUsed;							///Thruster seconds of fuel used
        float mass;
		bool shotPellet;						///True if satellite has shot a pellet in the given gametime
		float homeBase[3];
		short message;
	};

	struct OtherInfo {
	    unsigned short debrisTime[NUM_DEBRIS];
		unsigned short itemTime[NUM_ITEMS];
		float cometState[6];
        float score;
        float mass;
		float homeBase[3];
		short message;
	};

	struct debrisInfo {
		float pos[3];
		//lasso properties
		bool pickingUp;
		float axisVect[3];
	};

    struct ChallengeInfo {
        PlayerInfo me;
		OtherInfo other;
        debrisInfo debris[NUM_DEBRIS];
        float itemLoc[NUM_ITEMS][3];
		bool netBroken;
		int stage;
		unsigned int gameTime;
    };

    ChallengeInfo challInfo;

	/**
	 * (Required) Runs initialization for the ZR game at the start of a test. Use this function
	 * to reset all member variables.
	 */
	void init(void);

	/**
	 * (Required) Runs an update of the game rules and calls the user function loop(). The return
	 * value for this function indicates if the forceTorqueOut vector should be mixed into
	 * thruster firings.  The function should return 0 if the user does not activate any
	 * ZR API movement commands or implements their own thruster firing logic.
	 *
	 * /param forceTorqueOut forces and torques to be mixed into thruster firings
	 * /return return 1 if forceTorqueOut should be mixed into thruster firings and 0 otherwise
	 */
	bool update(float forceTorqueOut[6]);

	/**
	 * Applies zone-specific boundary constraints
	 * \param[out] forceTorqueOut length 6 array of forces and torques used to store additional forces if bounds are activated
	 * \return true if boundaries are violated
	 */

	bool enforceBoundaries(float forceTorqueOut[6]);

	/**
	 *Limits the direction in which the programmed SPHERE can travel and slows down the velocity if 
	 *it travels in the direction of the limit.
	 */
	void limitDirection(state_vector ctrlState, float ctrlControl[6], unsigned int idx, float dir);

	/**
	 * (Required) Called on every gspControl control cycle.  It should be used to send debug
	 * and telemetry information to the ground.
	 */
	void sendDebug(void);

	/**
	 * (Required) Processes SPHERES telemetry data
	 */
	void processRXData(default_rfm_packet packet);

	/**
	 * (Required) Initial state where the satellite is initialized.
	 */
	static const state_vector initState;

	/**
	 * Retrieves singleton instance of the game implementation
	 * \return The game implementation singleton
	 */
	static ZeroRoboticsGameImpl &instance();

	//Debris Field
	void createDebris(debrisInfo debris[NUM_DEBRIS]);
	bool hitDebris(float pos[3], float debrisLoc[3]);
	void checkHits();
	void activateSlowDown(state_vector myState);
	void activateBounce(state_vector myState);
	bool canClearDebrisNet(float sph1[3], float sph2[3], float debrisLoc[3]);
	void clearDebrisNet();
	void checkLasso();

	//Midway Area
	bool objectPickedUp(int objectNum);

	//Phase 2
    void updateCometStates();
    void updateGravity();

	//Math functions
	void vecMult(float* vec, float a, int len);
    float dist3d(float const* pos1,float const* pos2) const;
	float dist2d(float const* pos1,float const* pos2) const;
	int getRandomNumber();

	/**
	 * Constructor for binding an API implementation
	 */
	ZeroRoboticsGameImpl(ZeroRoboticsAPIImpl &apiImpl);

	///Reference to ZR API instance
	ZeroRoboticsAPIImpl &apiImpl;

	///Back pointer to the game instance
	ZeroRoboticsGame *game;


};

#endif
