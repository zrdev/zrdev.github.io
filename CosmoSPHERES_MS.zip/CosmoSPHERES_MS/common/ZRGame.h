#ifndef _ZR_GAME_H_
#define _ZR_GAME_H_

extern "C" {
	#include "pads.h"
}
#include "constants.h"
#include "spheres_constants.h"
#include "ZR_API.h"

/** \file ZRGame.h
 * Contains documentation of functions specific to the \todo GAME NAME IN HEADER DESCRIPTION
 * Use this documentation to learn about using the API functions available in the challenge.
 * General API operations for Zero Robotics are available under ZR_API.h.
 *
 * \see ZR_API.h
 */

//Forward declaration of the game implementation (not visible)
class ZeroRoboticsGameImpl;

//Forward declaration of API implementation
class ZeroRoboticsAPIImpl;

class ZeroRoboticsGame {

 public:

	/**
	 * Retrieves the singleton instance of the game API.  Users are not allowed to construct a game instance, so the
	 * API must be retrieved through this interface.
	 * \return singleton of the game API
	 */
	static ZeroRoboticsGame &instance();

	//DECLARATIONS FOR PUBLIC METHODS AND VARIALBES AVAILABLE TO USERS GO HERE

	//Debris Field
	//bool isNetBroken();
	//void breakNet();
	void getDebrisLocation(int debrisId, float loc[3]);
	bool haveDebris(int player, int debrisId);
	bool startLasso(int debrisId);

	//Midway Area
	bool haveItem(int player, int objectNum);

	//Phase 2
	void predictCometState(unsigned int dtSteps, float initState[6], float finalState[6]);
    void getCometState(unsigned int cometNumber, float state[6]);
    void faceTarget(float target[3]);
	bool isFacingComet();
	bool shootLaser();
	int laserShotsRemaining();

	//General Methods	
	float getMass();
	float getFuelRemaining();
    float getScore();
    float getOtherScore();
    bool isCollisionActive();
	bool isBounceActive();
//	bool wasRecoilActive();
	void sendMessage(unsigned char inputMsg);
	unsigned char receiveMessage();
	int getSphereID();

	/// Constructor for the game.  The provided references should be singleton instances.
	ZeroRoboticsGame(ZeroRoboticsGameImpl &impl, ZeroRoboticsAPIImpl &apiImpl);

private:
	///REQUIRED: reference to the game implementation, do not delete!
	ZeroRoboticsGameImpl &pimpl;
	ZeroRoboticsAPIImpl &apiImpl;
};


#endif
